package com.springboot.repository;


import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.springboot.domain.WeatherData;



public interface WeatherRepository extends CrudRepository<WeatherData, Long>{

	List<WeatherData> findByapiKeyIgnoreCase(String apiKey);
	
	int countByapiKeyIgnoreCaseAndDateTimeBetween(String apiKey,Timestamp t1,Timestamp t2);
}
