package com.springboot.config;

public class Constants {
	
	  public static final String WEATHER_API_URL= "http://api.openweathermap.org/data/2.5/weather?q={city},{country}&APPID={key}";

}
