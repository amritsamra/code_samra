package com.springboot.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springboot.config.Constants;
import com.springboot.domain.WeatherData;
import com.springboot.repository.WeatherRepository;

import java.net.URI;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;


@Component
public class WeatherService {

	@Autowired
	private  WeatherRepository weatherRepository; 
	    
	ObjectMapper objectMapper;
    RestTemplate restTemplate;
    
	public String getWeatherData(String country,String city,String apiKey) {
			URI url = new UriTemplate(Constants.WEATHER_API_URL).expand(city, country, apiKey);
	        restTemplate = new RestTemplate();
	        objectMapper = new ObjectMapper();
	        JsonNode root;
			try {
				Timestamp t1=new Timestamp(System.currentTimeMillis());
				Timestamp t2=new Timestamp(System.currentTimeMillis()- (60 * 60 * 1000));
				System.out.println("T1 : "+t1+" T2 : "+t2);
				int count = weatherRepository.countByapiKeyIgnoreCaseAndDateTimeBetween(apiKey,t2,t1);
				System.out.println("count : "+count);
				if(count<5) {
					ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
					root = objectMapper.readTree(response.getBody());		
					WeatherData weatherData=new WeatherData();
					weatherData.setApiKey(apiKey);
					weatherData.setDateTime(new Timestamp(System.currentTimeMillis()));
					weatherData.setResponse(root.path("weather").get(0).path("description").asText());
					weatherRepository.save(weatherData);
					return  root.path("weather").get(0).path("description").asText();
				}else {
				return "Hourly limit has been exceeded. Please try using another API key";
				}
				
			
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (HttpClientErrorException e) {
			      System.out.println(e.getStatusCode());
			      return e.getResponseBodyAsString();
			      
			    }
		
       return null;
	}
}
