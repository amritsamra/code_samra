package com.springboot.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.service.WeatherService;


@RestController
@RequestMapping("/api")
public class WeatherController {
	
	 @Autowired
	 private WeatherService weatherService;
	
	 @GetMapping("/getweatherInfo")
	 public String getWeatherInformation(@RequestParam(value = "countryName") String countryName,@RequestParam(value = "cityName") String cityName,@RequestParam(value = "apiKey") String apiKey) {
	        return weatherService.getWeatherData(countryName, cityName, apiKey);
	 }

}
